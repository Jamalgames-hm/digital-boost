const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "×" : "☰";
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("contactForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = new FormData(form);
  const message = [
    "DIGITAL BOOST PROJECT ENQUIRY",
    `Name: ${data.get("name")}`,
    `Service: ${data.get("service")}`,
    `Project details: ${data.get("details")}`
  ].join("\\n");

  // This demo copies the enquiry text locally. It does not transmit or store it.
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(message).then(() => {
      document.getElementById("formNote").textContent =
        "Your enquiry text has been copied. Ask your parent or guardian to help send it using a supervised business contact.";
    }).catch(() => showMessage(message));
  } else {
    showMessage(message);
  }
});

function showMessage(message) {
  const note = document.getElementById("formNote");
  note.textContent = "Copy this enquiry and ask your parent or guardian to help send it: " + message;
}

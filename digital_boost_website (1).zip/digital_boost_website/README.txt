DIGITAL BOOST WEBSITE

FILES
- index.html: website content
- style.css: colours, layout and responsive design
- script.js: mobile menu and demo enquiry form

HOW TO PREVIEW
1. Keep all three files in the same folder.
2. Double-click index.html to open it in your browser.
3. Edit the text and prices in index.html as needed.

BEFORE PUBLISHING
- Ask a parent or guardian to review and supervise the business.
- Replace the sample portfolio projects with your own work.
- Confirm all prices and what each package includes.
- Add a business email/contact method managed by your parent or guardian.
- The enquiry form is a front-end demo: it does not send messages to you or save customer details.
- Do not publish your home address, school, personal phone number or private information.
- Hosting/domain fees are not included. A parent/guardian should help choose a hosting service and check its age and payment rules.

This is a starter website, not a registered business or payment system.
